README for...

  jQuery.validity alpha 2 (v. 0.9.1)
  http://code.google.com/p/validity
  Copyright (c) 2009, Wyatt Allen
  Licenced under the New BSD Licence
  http://www.opensource.org/licenses/bsd-license.php
  Revision 3. Feb. 15 2009
  
In order to make use of this demo, you'll need to install the actual jQuery 
library, as it is not included in this archive. The demo page 'index.htm' makes
reference to 'jquery.js' for the actual library import, so either rename the 
library that you download or edit the demo page in order to load the correct 
file.

The demo page explains the use of the validity framework to an extent, but for
a complete guide, refer to the documentation.

Thanks!
